from flet import *



def main(page: Page):
    page.title = "calculatrice"
    page.window.width = 390
    page.window.height = 740
    page.window.top = 10
    page.window.left = 920
    page.vertical_alignment = MainAxisAlignment.CENTER
    page.theme_mode=ThemeMode.SYSTEM

    page.appbar = AppBar(
        leading_width=40,
        title=Text("Calculator"),
        center_title=False,
        bgcolor=colors.BLUE_100,
        
    )

    result=TextField(
            label="النتيجة",
            read_only=True,
            text_size=50,
            width=300,
            expand=True,
            text_align=TextAlign.CENTER,
            )


    def button_click(e):
        if e.control.data == "=":
            # تنفيذ العملية
            try:
                # استخدام eval لتنفيذ التعبير
                result.value = str(eval(result.value))
            except Exception as ex:
                result.value = "خطأ"
        elif e.control.data == "AC":
            # مسح النتيجة
            result.value = ""
        elif e.control.data == "%":
            # تنفيذ العملية
            try:
                # استخدام eval لتنفيذ التعبير
                result.value = str(eval(result.value))
                result.value = str(float(result.value) / 100)
            except Exception as ex:
                result.value = "خطأ"
        else:
            # إضافة الرقم أو العملية إلى النتيجة
            result.value += e.control.data



        page.update()

    buton = ["AC",".","/","00"]
    buton1 = ["7","8","9","+"]
    buton2 = ["4","5","6","-"]
    buton3 = ["1","2","3","*"]
    buton4 = ["0","=","%"]

    button_list = Row(
        controls=[CupertinoButton(content=Text(b,color=colors.WHITE,size=15),padding=0,bgcolor=colors.BLUE_100,color=colors.WHITE, data=b,width=80,height=50, on_click=button_click,expand=True) for b in buton],alignment=MainAxisAlignment.CENTER

        #controls=[ElevatedButton(text=b,bgcolor=colors.AMBER,color=colors.WHITE, data=b,width=80,height=50, on_click=button_click) for b in buton],alignment=MainAxisAlignment.CENTER
    )
    button_list1 = Row(
        controls=[CupertinoButton(content=Text(b,color=colors.WHITE,size=15),padding=0,bgcolor=colors.BLUE_100,color=colors.WHITE, data=b,width=80,height=50, on_click=button_click,expand=True) for b in buton1],alignment=MainAxisAlignment.CENTER

        #controls=[ElevatedButton(text=b,bgcolor=colors.AMBER,color=colors.WHITE, data=b,width=80,height=50, on_click=button_click) for b in buton1],alignment=MainAxisAlignment.CENTER
    )
    button_list2 = Row(
        controls=[CupertinoButton(content=Text(b,color=colors.WHITE,size=15),padding=0,bgcolor=colors.BLUE_100,color=colors.WHITE, data=b,width=80,height=50, on_click=button_click,expand=True) for b in buton2],alignment=MainAxisAlignment.CENTER

        #controls=[ElevatedButton(text=b,bgcolor=colors.AMBER,color=colors.WHITE, data=b,width=80,height=50, on_click=button_click) for b in buton2],alignment=MainAxisAlignment.CENTER
    )
    button_list3 = Row(
        controls=[CupertinoButton(content=Text(b,color=colors.WHITE,size=15),padding=0,bgcolor=colors.BLUE_100,color=colors.WHITE, data=b,width=80,height=50, on_click=button_click,expand=True) for b in buton3],alignment=MainAxisAlignment.CENTER

        #controls=[ElevatedButton(text=b,bgcolor=colors.AMBER,color=colors.WHITE, data=b,width=80,height=50, on_click=button_click) for b in buton3],alignment=MainAxisAlignment.CENTER
    )
    button_list4 = Row(
        controls=[CupertinoButton(content=Text(b,color=colors.WHITE,size=15),padding=0,bgcolor=colors.BLUE,color=colors.WHITE, data=b,width=170,height=50, on_click=button_click,expand=True) for b in buton4],alignment=MainAxisAlignment.CENTER
    )

    page.add(
        Row([result],alignment=MainAxisAlignment.CENTER),button_list,button_list1,button_list2,button_list3,button_list4
        )


app(main)