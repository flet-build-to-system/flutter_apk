package {{ cookiecutter.org_name }}.{{ cookiecutter.project_name }}

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
