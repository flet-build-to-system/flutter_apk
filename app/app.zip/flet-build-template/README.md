# flet-build-template
 A Flutter bootstrap project Cookiecutter template for packaging Flet app
